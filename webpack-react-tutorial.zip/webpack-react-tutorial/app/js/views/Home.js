import React, { Component } from 'react';

export default class Home extends Component {
  render() {
    return (
      <div className='Home'>
        Home page
      </div>
    );
  }
}
