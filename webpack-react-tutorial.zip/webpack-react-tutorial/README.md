# Setting up Webpack, Babel and React from scratch

This is a demo repository 
Install dependencies

```
npm install
```

To start run

```
npm run dev
```
